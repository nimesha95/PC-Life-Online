<div class="row">
    <nav class="col-md-3">
        <ul class="nav nav-pills nav-stacked" data-spy="affix" data-offset-top="205">
            <li class="dropdown active">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Brand New Computers <span
                            class="caret"></span></a>
                <ul class="dropdown-menu multi-column columns-2">
                    <div class="row">
                        <div class="col-sm-6">
                            <ul class="multi-column-dropdown">
                                <li><a href="#">HP</a></li>
                                <li><a href="#">Samsung</a></li>
                                <li><a href="#">Lenovo</a></li>
                                <li><a href="#">Dell</a></li>
                                <li><a href="#">Others</a></li>
                            </ul>
                        </div>
                    </div>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Used Desktop Computers <span
                            class="caret"></span></a>
                <ul class="dropdown-menu multi-column columns-2">
                    <div class="row">
                        <div class="col-sm-6">
                            <ul class="multi-column-dropdown">
                                <li><a href="items.html.php?item=tb_desktop"><b>Used Computers</b></a></li>
                                <li><a href="#">HP</a></li>
                                <li><a href="#">Samsung</a></li>
                                <li><a href="#">Lenovo</a></li>
                                <li><a href="#">Dell</a></li>
                                <li><a href="#">Others</a></li>
                            </ul>
                        </div>
                    </div>
                </ul>
            </li>
        </ul>
    </nav>


