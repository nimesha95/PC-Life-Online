<?php $__env->startSection('title'); ?>
    Some header passed from the parameters
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials/desktop_sbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-9">
        <?php $__currentLoopData = array_chunk($items,3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemschunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <?php $__currentLoopData = $itemschunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-4">
                        <div class="thumbnail">
                            <img src="<?php echo e($item->image); ?>">
                            <div class="caption">
                                <h3><?php echo e($item->name); ?></h3>
                                <p><?php echo e($item->description); ?></p>
                                <div class="clearfix">
                                    <div class="pull-left price">
                                        <h4><?php echo e($item->price); ?> LKR</h4>
                                    </div>
                                    <a href="#"
                                       class="btn btn-success pull-right" role="button"> Add to Cart </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>